﻿using SportsStore.Models.Domain;
using System;
using System.ComponentModel;
using System.Web.ModelBinding;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace SportsStore.ViewModels
{
    public class ProductViewModel
    {
        [StringLength(100, MinimumLength = 5)]
        [Required(ErrorMessage = "{0} is verplicht")]
        public int ProductId { get; set; }
        public string Name { get; set; }
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }
        [Range(typeof(decimal), "1", "3000")]
        [Required(ErrorMessage = "{0} is verplicht")]
        public decimal Price { get; set; }
        public bool InStock { get; set; }
        [Required(ErrorMessage = "{0} is verplicht")]
        public Availability Availability { get; set; }
        [Display(Name = "Available till")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "(0:yyyy-MM-dd)", ApplyFormatInEditMode = true)]
        public DateTime? AvailableTill { get; set; }
        [Required(ErrorMessage = "{0} is verplicht")]
        [DisplayName("Category")]
        public int CategoryId { get; set; }

        public ProductViewModel()
        {
            
        }

        public ProductViewModel(Product p)
        {
            ProductId = p.ProductId;
            
            Name = p.Name;
            Description = p.Description;
            
            Price = p.Price;
            InStock = p.InStock;
            
            Availability = p.Availability;
            AvailableTill = p.AvailableTill;
           
            if (p.Category!=null)
                CategoryId = p.Category.CategoryId;
        }
    }
}