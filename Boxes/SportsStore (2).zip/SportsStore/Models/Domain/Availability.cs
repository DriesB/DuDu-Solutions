﻿namespace SportsStore.Models.Domain
{
    public enum Availability
    {
        ShopOnly,
        OnlineOnly,
        ShopAndOnline
    }
}