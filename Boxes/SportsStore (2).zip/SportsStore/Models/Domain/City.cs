﻿
namespace SportsStore.Models.Domain
{
    public class City
    {
        public string Postalcode { get; set; }
        public string Name { get; set; }
    }
}