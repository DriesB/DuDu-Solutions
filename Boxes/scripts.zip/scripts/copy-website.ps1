echo "Copy website folder"
Copy-Item C:\vagrant\website C:\website -Recurse
echo "Done!"
 		 